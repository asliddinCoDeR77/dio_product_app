sealed class ProductEvents {}

final class GetProductsEvent extends ProductEvents {}

final class AddProductsEvent extends ProductEvents {}

final class EditProductsEvent extends ProductEvents {}

final class DeleteProductsEvent extends ProductEvents {}
